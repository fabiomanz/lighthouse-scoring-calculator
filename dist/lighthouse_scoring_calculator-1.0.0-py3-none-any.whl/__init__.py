__version__ = "1.0.0"
__author__ = "Fabio Manz"
__author_email__ = "fabio.manz@t-online.de"
__license__ = "GPL-3.0"
